# Name, Beschreibung und Chatstarter – Trainer-Assistent

Die Felder des Fobizz-Formulars „Assistent anlegen“, zum Kopieren.

## Name

```
Trainer
```

## Beschreibung (Feld „Beschreibung“)

```
Aus Ihrem eigenen Arbeitsblatt, Hefteintrag oder Ihrer Wortliste wird ein interaktiver Trainer für iPad und Tafel: Lösungswege Schritt für Schritt, die Aufgaben des Blatts per Knopf, Zufallsaufgaben in drei Stufen – für Mathematik, Sprachen und jedes Fach mit festen Verfahren. Material hochladen, „Daraus bitte den Trainer“ schreiben, den Code in den Baukasten einfügen.
```

(ca. 380 Zeichen – falls das Feld kürzer ist, den ersten Satz verwenden.)

## Chatstarter (für Lehrkräfte)

```
Daraus bitte den Trainer. (Material als Datei, Foto oder Text anhängen)
```

```
Welche Aufgaben aus meinem Material eignen sich für einen Trainer? Bitte erst nur den Plan.
```

```
Baue einen Blitz mit Zufallsaufgaben zum Thema __ für Klasse __.
```

```
Der Baukasten meldet: __
```

## Weitere Einstellungen

| Feld | Einstellung |
|---|---|
| Vorschaubild | `03_Motivbild_Trainer.png` hochladen |
| Plugins | **keine** – der Assistent arbeitet nur mit dem Material und seinem Skill |
| Sprachmodell | Claude Sonnet 5.5 |
| Erweitertes Denken | **aus**, falls angeboten – sonst dauern die Antworten länger und können abbrechen |
| Rolle und Instruktionen | `01_Rolle-und-Instruktionen.md` |
| Hintergrundwissen | die drei Dateien aus `04_Hintergrundwissen/` (Schnittstelle, Beispiel Mathematik, Beispiel Sprachen) |
| Skills | `05_Skill/trainer.zip` |
| Remix erlauben | nach Wunsch – der Assistent enthält keine Schülerdaten und keine Lösungen zu Ihren Blättern |
