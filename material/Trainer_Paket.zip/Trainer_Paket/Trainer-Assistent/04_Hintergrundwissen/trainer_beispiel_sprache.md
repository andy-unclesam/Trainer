# Wissensdatei: Getestetes Beispiel Sprachen (Latein)

Zum Skill „trainer“. Thema „a- und o-Deklination“ mit einer kleinen Wortliste aus dem Material: ein Vorführer „Form bestimmen“ (Wort suchen → Stamm → Endung → alle Treffer in der Tabelle → bei Mehrdeutigkeit alle Möglichkeiten) mit den Aufgaben „AB Nr. 1 a)–c)“ als Knöpfe und 🎲 Zufall, dazu ein Blitz „Formen bilden“.

In den Baukasten eingefügt meldet er „Selbsttest ✓ 1804 Aufgaben geprüft“ (rund 4 100 Zeichen).

Worauf es bei Sprachen ankommt:
- **Daten statt Rechnung:** Die Wortliste steht im Code (nur Wörter aus dem Material oder ein kleiner Grundwortschatz). Formen werden aus Stamm + Endungstabelle gebildet, nie einzeln eingetippt. Unregelmäßige Formen gehören als eigene Einträge in die Wortliste.
- **Unabhängige Kontrolle:** `MUSTER` enthält für je ein Wort pro Klasse alle Formen von Hand geschrieben; `pruefe()` vergleicht die Tabelle damit und prüft, dass jede genannte Bestimmung die eingegebene Form ergibt.
- **Mehrdeutigkeit zeigen, nicht verschweigen:** `treffer()` sucht alle passenden Felder; die Lösung nennt alle („Gen. Sg. oder Dat. Sg. oder Nom. Pl.“).
- **Darstellung:** `tabelle()` mit `*` markiert die Treffer; Formen kursiv, Endungen fett. Für Satzanalysen `marke()` (siehe Schnittstelle).
- Fachbegriffe und Abkürzungen aus dem Material übernehmen (Nom., Gen. … bzw. Nominativ …); Längenzeichen nur, wenn das Material sie verwendet.

```js
var NAME = "Lateintrainer";
var THEMA = "a- und o-Deklination";
/* Wortliste aus dem Material: Wörterbuchform, Genitiv, Genus, Bedeutung */
var WL = [["amica", "amicae", "f", "Freundin"], ["villa", "villae", "f", "Landhaus"], ["servus", "servi", "m", "Sklave"], ["dominus", "domini", "m", "Herr"], ["donum", "doni", "n", "Geschenk"], ["templum", "templi", "n", "Tempel"]];
var KAS = ["Nom.", "Gen.", "Dat.", "Akk.", "Abl."];
var END = {a: [["a", "ae", "ae", "am", "a"], ["ae", "arum", "is", "as", "is"]], o: [["us", "i", "o", "um", "o"], ["i", "orum", "is", "os", "is"]], n: [["um", "i", "o", "um", "o"], ["a", "orum", "is", "a", "is"]]};
function dk(w){ return /ae$/.test(w[1]) ? "a" : w[2] === "n" ? "n" : "o"; }
function stamm(w){ return w[1].replace(/(ae|i)$/, ""); }
function form(w, k, n){ return stamm(w) + END[dk(w)][n][k]; }
function treffer(f){ var t = []; WL.forEach(function(w){ [0, 1].forEach(function(n){ for (var k = 0; k < 5; k++) if (form(w, k, n) === f) t.push({w: w, k: k, n: n}); }); }); return t; }
function kurz(t){ return KAS[t.k] + " " + (t.n ? "Pl." : "Sg."); }
function tab(w, tr){ return tabelle(["", "Singular", "Plural"], KAS.map(function(k, i){ return [k].concat([0, 1].map(function(n){ var hit = tr.some(function(t){ return t.w === w && t.k === i && t.n === n; }); return (hit ? "*" : "") + stamm(w) + "<b>" + END[dk(w)][n][i] + "</b>"; })); })); }
/* unabhängige Kontrolle: Musterformen von Hand (Nom. Gen. Dat. Akk. Abl., Sg | Pl) */
var MUSTER = {amica: "amica amicae amicae amicam amica|amicae amicarum amicis amicas amicis", servus: "servus servi servo servum servo|servi servorum servis servos servis", donum: "donum doni dono donum dono|dona donorum donis dona donis"};
function musterOk(){ return Object.keys(MUSTER).every(function(l){ var w = WL.filter(function(x){ return x[0] === l; })[0], s = MUSTER[l].split("|");
  return [0, 1].every(function(n){ return s[n].split(" ").join() === [0, 1, 2, 3, 4].map(function(k){ return form(w, k, n); }).join(); }); }); }
var TRAINER = [
  { id: "v1", titel: "Form bestimmen", art: "vorfuehrer",
    eingabe: {platzhalter: "z. B. servis", beispiel: "servis"},
    parse: function(t){ var f = String(t).toLowerCase().replace(/[^a-z]/g, ""), tr = treffer(f);
      if (!tr.length) return {fehler: "Diese Form kenne ich nicht. Wörter: " + WL.map(function(w){ return w[0]; }).join(", ") + "."};
      return {f: f, w: tr[0].w, tr: tr}; },
    titelVon: function(a){ return "Bestimme Kasus und Numerus: <i>" + a.f + "</i>"; },
    schritte: function(a){ var w = a.w; return [
      {erkl: "Suche das Wort im Wortschatz.", zeile: "<i>" + w[0] + ", " + w[1] + "</i> " + w[2] + ". – " + w[3]},
      {erkl: "Der Genitiv zeigt die Deklination und den Stamm <i>" + stamm(w) + "-</i>.", bild: tab(w, [])},
      {erkl: "Trenne Stamm und Endung.", zeile: "<i>" + stamm(w) + " | " + a.f.slice(stamm(w).length) + "</i>"},
      {erkl: "Markiere alle Treffer in der Tabelle.", bild: tab(w, a.tr)},
      {erkl: a.tr.length > 1 ? "Mehrere Möglichkeiten – erst der Satz entscheidet." : "Nur eine Möglichkeit.", zeile: "<i>" + a.f + "</i> = " + a.tr.map(function(t){ return erg(kurz(t)); }).join(" oder ")}]; },
    presets: [{gruppe: "AB Nr. 1", label: "a)", text: "servis"}, {gruppe: "AB Nr. 1", label: "b)", text: "amicae"}, {gruppe: "AB Nr. 1", label: "c)", text: "dona"}],
    zufall: function(s){ var w = zw(s === "b" ? WL.slice(0, 4) : WL); return form(w, zz(0, 4), zz(0, 1)); },
    pruefe: function(a){ return musterOk() && a.tr.every(function(t){ return form(t.w, t.k, t.n) === a.f; }); } },
  { id: "b1", titel: "Formen bilden", art: "blitz",
    erzeuge: function(s){ var w = zw(s === "b" ? WL.slice(0, 4) : WL), k = zz(0, 4), n = zz(0, 1), f = form(w, k, n);
      return {frage: "Bilde: " + KAS[k] + " " + (n ? "Pl." : "Sg.") + " von <i>" + w[0] + "</i>", loesung: erg("<i>" + f + "</i>") + tab(w, [{w: w, k: k, n: n}]), daten: {w: w, k: k, n: n, f: f}}; },
    pruefe: function(d){ return musterOk() && treffer(d.f).some(function(t){ return t.w === d.w && t.k === d.k && t.n === d.n; }); } }
];
```
