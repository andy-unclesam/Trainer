# Wissensdatei: Schnittstelle für Vorführer, Blitz und Werkzeug

Zum Skill „trainer“. Beschreibt den Trainer-Code, den du ausgibst. Die Lehrkraft fügt ihn in den Trainer-Baukasten ein („trainer-baukasten.html“ oder online); Aussehen, Kopfleiste, Bedienung, Selbsttest und Speichern erledigt der Baukasten.

## Aufbau des Trainer-Codes

```js
var NAME = "Mathematiktrainer";         // Titel vorne: „Mathematiktrainer“, „Lateintrainer“, „Englischtrainer“ … (ohne NAME: „Trainer“)
var THEMA = "Gleichungen lösen";        // erscheint im Titel: „Mathematiktrainer – Gleichungen lösen“
/* eigene Hilfsfunktionen und Daten für das Thema (lesen, rechnen, Formen bilden, darstellen) */
var TRAINER = [ { …Vorführer… }, { …Blitz… } ];
```

### Vorführer
```js
{ id: "v1",                       // eindeutig, nur Buchstaben/Ziffern
  titel: "Gleichung Schritt für Schritt",
  art: "vorfuehrer",
  eingabe: {platzhalter: "z. B. x − 27 = 58", beispiel: "x − 27 = 58"},   // beispiel wird beim Laden gezeigt
  parse: function(text){ … return aufgabe; }                 // Objekt mit den Daten der Aufgabe
                                                            // ODER {fehler: "Bitte so eingeben: …"}
                                                            // optional aufgabe.hinweis = "…" (erscheint unter der Aufgabe)
  titelVon: function(aufgabe){ return "HTML der Aufgabe"; },
  schritte: function(aufgabe){ return [ {erkl: "…", zeile: "…", bild: "…"}, … ]; },
  presets: [{gruppe: "AB Nr. 2", label: "a)", text: "x + 57 = 83"}, …],
  zufall: function(stufe){ return "Aufgabentext, den parse lesen kann"; },   // optional
  pruefe: function(aufgabe){ return true/false; } }          // unabhängige Kontrolle
```
Ein Schritt (Objekt in schritte):
- **erkl** (Pflicht): kurzer Erklärsatz in Schülersprache – erscheint rechts als nummerierte Liste.
- **zeile** (optional): eine Zeile, wie sie ins Heft kommt – erscheint links unter der Aufgabe und bleibt stehen.
- **bild** (optional): SVG oder HTML, das links oben angezeigt wird; ein späterer Schritt mit bild ersetzt das frühere Bild (so entsteht eine Animation: Bögen am Rechenstrich nacheinander, ein Satz, in dem nach und nach mehr markiert ist, eine Tabelle mit markierten Treffern).
Der erste Schritt ist meist „Lies …/Was ist gegeben?“ ohne zeile. Der letzte Schritt ist – wo sinnvoll – die Probe bzw. Kontrolle.

### Blitz
```js
{ id: "b1", titel: "Gleichungs-Blitz", art: "blitz",
  erzeuge: function(stufe){ return {
      frage: "Löse: …",                         // HTML, mit Operator
      loesung: "… = " + erg(…),                 // HTML, vollständige Kurzlösung
      daten: {…},                               // alles, was pruefe braucht
      vorfuehren: {trainer: "v1", text: "…"}    // optional: Knopf „Im Vorführer zeigen ▸“
  }; },
  pruefe: function(daten){ return true/false; } }
```

### Werkzeug (optional, für Aufgaben, bei denen das Kind selbst entscheidet)
Das Kind baut selbst – z. B. einen Faktorbaum, bei dem es jedes Mal wählt, welches Produkt es als Nächstes nimmt. Nur einsetzen, wenn genau diese eigene Entscheidung der Kern des Themas ist; höchstens ein Werkzeug pro Trainer. Der Baukasten liefert Eingabefeld, Knöpfe der Aufgaben, „◂ Zurück“ (macht den letzten Zug rückgängig), „Neu beginnen“ und optional einen Lösen-Knopf.
```js
{ id: "w1", titel: "Faktorbaum bauen", art: "werkzeug",
  eingabe: {platzhalter: "z. B. 360", beispiel: "210"},
  parse: function(text){ … return aufgabe; },                 // wie beim Vorführer, auch {fehler: "…"}
  titelVon: function(aufgabe){ return "HTML der Aufgabe"; },
  anfang: function(aufgabe){ return {…}; },                   // Startzustand – NUR Daten (Zahlen, Texte, Listen, Objekte), wird für „Zurück“ als JSON gespeichert
  zeichne: function(aufgabe, zustand){ return "HTML/SVG"; },  // anklickbare Teile bekommen data-w="…" (Knöpfe: <button data-w="z:4">; SVG: <g data-w="n:01" tabindex="0" role="button">)
  aktion: function(aufgabe, zustand, wert){ … return true; }, // wert = Inhalt von data-w; Zustand ändern; false = ungültiger Zug (nichts passiert)
  status: function(aufgabe, zustand){ return "Hinweis unter der Werkbank"; },   // optional: was als Nächstes zu tun ist, „Fertig: …“
  loesen: function(aufgabe, zustand){ … }, loesenText: "Automatisch fertig zerlegen",   // optional: führt alle restlichen Züge aus
  presets: [{gruppe: "Material", label: "210", text: "210"}, …],
  zufall: function(stufe){ return "Aufgabentext"; },          // optional
  pruefe: function(aufgabe, zustand){ return true/false; } }  // Selbsttest: zustand nach anfang + loesen; zusätzlich zufällige andere Wege prüfen
```
Tastatur im Werkzeug: Tab wählt einen anklickbaren Teil, Enter/Leertaste löst ihn aus, ← macht den letzten Zug rückgängig, A = Lösen, N = neue Zufallsaufgabe.

### Hilfsfunktionen im Baukasten (benutzen, nicht neu schreiben)
- `zz(a, b)` – ganze Zufallszahl von a bis b
- `zw(liste)` – zufälliges Element; `mischen(liste)` – neue, gemischte Liste
- `ggT(a, b)` – größter gemeinsamer Teiler
- `nf(zahl)` – Anzeige mit −, schmalem Tausender-Leerzeichen und Dezimalkomma
- `bruch(z, n)` – Bruch mit waagrechtem Bruchstrich
- `v("x")` – Variable kursiv; `erg(text)` – Endergebnis doppelt unterstrichen
- `zahl(text)` – liest eine Eingabe (− oder -, Komma) als Zahl, sonst null
- `marke(text, etikett, nr)` – Wort oder Wortgruppe farbig unterstrichen, darunter ein kleines Etikett (z. B. Satzglied, Wortart, Satzteil); nr 1–5 wählt Farbe und Linie: 1 blau einfach, 2 rot doppelt, 3 grün gestrichelt, 4 lila gepunktet, 5 orange kräftig
- `tabelle(kopf, zeilen)` – kleine Tabelle; kopf = Liste der Überschriften, zeilen = Liste von Listen; eine Zelle, die mit `*` beginnt, wird markiert (z. B. Treffer in einer Deklinations- oder Konjugationstabelle)

### CSS-Klassen im Baukasten
- `hl` Markierung (Textmarker), `v` Variable, `erg` Endergebnis, `bruch` Bruch, `m1`–`m5` (über marke) – für eigenes HTML in erkl, zeile, bild, frage und loesung. Eigene Farben als `style="color:var(--blau)"` bzw. `var(--gruen)`, `var(--gelb)` (Hintergrund), damit der Tafelmodus funktioniert.

### Tastatur und Kopfleiste (im Baukasten schon fertig)
- → oder Leertaste: nächster Schritt bzw. Aufdecken/neue Aufgabe; ←: zurück; A: alles zeigen; N: neue Aufgabe
- 1–4: Reiter wechseln; T: Tafelmodus (dunkel, kontrastreich); F: Vollbild; + und −: Schriftgröße

## Typische Vorführer-Schritte (Orientierung)
- **Gleichung lösen:** Wo steht die Variable? → Umkehraufgabe aufschreiben → ausrechnen → Probe.
- **Term berechnen:** Was wird zuerst gerechnet (Klammern, Punkt vor Strich)? → je Rechenschritt eine zeile → Ergebnis.
- **Text → Term:** Verb im Imperativ → Art des Terms → Signalwort (zu/zur, von) → Klammern füllen → Wert berechnen (Satz als bild, nach und nach markiert).
- **Bruch kürzen/erweitern:** ggT bzw. Erweiterungszahl bestimmen → Zähler und Nenner teilen bzw. multiplizieren → Ergebnis.
- **Schriftliches Rechnen:** Stelle für Stelle von rechts; ein Schritt je Stelle mit Übertrag; Darstellung als kleine HTML-Tabelle im bild-Feld, die mit jedem Schritt eine Ziffer mehr zeigt.
- **Form bestimmen (Sprachen):** Wort in der Wortliste suchen → Stamm und Klasse (Deklination, Konjugation) erkennen → Stamm und Endung trennen → alle Treffer in der Tabelle markieren → bei Mehrdeutigkeit alle Möglichkeiten nennen.
- **Satz analysieren (Sprachen):** Prädikat suchen → Subjekt (passt im Numerus/in der Person) → Objekte nach Kasus → übrige Satzglieder → Übersetzung; der Satz als bild, jeder Schritt markiert mit marke() ein Satzglied mehr.
- **Formen bilden (Sprachen):** Grundform → Stamm → passende Endung bzw. Regel (z. B. Zeitform) → Form; unregelmäßige Formen stehen in der Wortliste und werden nicht mit der Regel gebildet.

### Muster: einfaches SVG-Bild (Zahlenstrahl)
```js
function strahl(von, bis, markiert){   // Zahlenstrahl mit markierten Zahlen
  var W = 600, x = function(z){ return 30 + (z - von) / (bis - von) * (W - 60); }, s = '<svg viewBox="0 0 ' + W + ' 70" width="100%" style="max-width:36rem">';
  s += '<line x1="20" y1="35" x2="' + (W - 15) + '" y2="35" stroke="currentColor" stroke-width="2"/>';
  for (var z = von; z <= bis; z++) s += '<line x1="' + x(z) + '" y1="29" x2="' + x(z) + '" y2="41" stroke="currentColor"/>' + '<text x="' + x(z) + '" y="62" text-anchor="middle" font-size="14" fill="currentColor">' + nf(z) + '</text>';
  (markiert || []).forEach(function(z){ s += '<circle cx="' + x(z) + '" cy="35" r="6" fill="#1d4ed8"/>'; });
  return s + '</svg>'; }
```
In einem Schritt: `{erkl: "Markiere 3 und 7.", bild: strahl(0, 10, [3, 7])}`.

### Muster: Satz mit markierten Satzgliedern
```js
function satzBild(woerter, rollen, bis){   // woerter: ["Dominus", "servum", "vocat"], rollen: ["S", "AO", "P"], bis: schon markierte Rollen
  var R = {P: ["Präd.", 2], S: ["Subj.", 1], AO: ["Akk-Obj.", 3], DO: ["Dat-Obj.", 4], ADV: ["Adv.", 5]};
  return '<div style="font-size:1.25rem;line-height:2.2">' + woerter.map(function(w, i){ var r = rollen[i];
    return bis.indexOf(r) >= 0 ? marke(w, R[r][0], R[r][1]) : w; }).join(" ") + '.</div>'; }
```
In einem Schritt: `{erkl: "Suche das Prädikat: Personalendung -t.", bild: satzBild(w, r, ["P"])}`.
