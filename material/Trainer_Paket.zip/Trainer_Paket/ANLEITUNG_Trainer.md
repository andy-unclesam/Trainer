# Der Trainer – Anleitung

*Stand: 21. November 2026 · Andreas Hemmeter · Begleitmaterial zum Beitrag https://andreas-hemmeter.de/Trainer/*

Der Trainer ist eine HTML-Datei für das iPad der Kinder und für die Tafel. Er führt Lösungswege Schritt für Schritt vor, lädt die Aufgaben Ihres Arbeitsblatts per Knopf, erzeugt Zufallsaufgaben in drei Stufen und kann die Kinder auch selbst bauen lassen (etwa einen Faktorbaum, bei dem sie jedes Produkt selbst wählen) – in Mathematik, in Sprachen wie Latein und in jedem Fach, in dem es Verfahren mit festen Schritten gibt. Den Trainer zu Ihrem Material schreibt ein **KI-Assistent in Fobizz**. Er liefert nur einen kurzen Code-Block. Den fügen Sie in den **Baukasten** ein, eine Seite im Browser. Der Baukasten macht daraus eine fertige Datei.

(Früher hieß der Assistent „Mathematiktrainer“. Mathematik-Code aus dem alten Assistenten läuft im neuen Baukasten unverändert.)

## Was in diesem Paket liegt

```
Trainer_Paket/
├─ ANLEITUNG_Trainer.md                         ← diese Datei
├─ trainer-baukasten.html                       der Baukasten (läuft offline im Browser; online: andreas-hemmeter.de/Trainer/baukasten/)
├─ Beispiel_Trainer_Gleichungen.html            fertiger Beispiel-Trainer Mathematik
├─ Beispiel_Trainer_Latein_Deklination.html     fertiger Beispiel-Trainer Latein
└─ Trainer-Assistent/
   ├─ 01_Rolle-und-Instruktionen.md             Text für „Rolle und Instruktionen“
   ├─ 02_Name-Beschreibung-Chatstarter.md       Name, Beschreibung, vier Chatstarter, Einstellungen
   ├─ 03_Motivbild_Trainer.png (+ .svg)         Vorschaubild 1024 × 1024
   ├─ 04_Hintergrundwissen/
   │  ├─ trainer_schnittstelle.md               Aufbau von Vorführer, Blitz und Werkzeug, Hilfsfunktionen (auch für Sprachen)
   │  ├─ trainer_beispiel.md                    getesteter Beispiel-Code Mathematik (Gleichungen, Brüche kürzen)
   │  └─ trainer_beispiel_sprache.md            getesteter Beispiel-Code Latein (a- und o-Deklination)
   └─ 05_Skill/trainer.zip                      der Skill (SKILL.md mit Entscheidungsraster, Regeln, Prüfliste; dieselben Referenzdateien)
```

## Den Assistenten einrichten

**Weg A – per Remix (empfohlen, Fobizz).** Melden Sie sich in Fobizz an und öffnen Sie die Vorlage: https://app.fobizz.com/ai/chats/public_assistants/6aa1ea34-7afd-454d-8960-e6dc25832110?token=d74998fafe4035edf822bbc30adc2723. Klicken Sie oben rechts auf „Remix“. Die Kopie mit Instruktionen, Skill, Hintergrundwissen, Chatstartern und Bild liegt danach in Ihrer Ablage. Prüfen Sie dort das Sprachmodell (Claude Sonnet 5.5).

**Weg B – selbst anlegen** (Fobizz ohne Remix, Claude-Projekt oder ein anderes Werkzeug):

1. **Bild:** `03_Motivbild_Trainer.png`. **Name, Beschreibung, Chatstarter:** aus `02_Name-Beschreibung-Chatstarter.md`.
2. **Rolle und Instruktionen:** den Inhalt von `01_Rolle-und-Instruktionen.md`.
3. **Sprachmodell:** Claude Sonnet 5.5 (oder das stärkste Claude-Modell Ihres Werkzeugs). **Plugins:** keine. **Erweitertes Denken:** aus, falls angeboten.
4. **Hintergrundwissen:** die drei Dateien aus `04_Hintergrundwissen/`.
5. **Skills:** `05_Skill/trainer.zip`. Nimmt Ihr Werkzeug keine Skills an, hängen Sie den Inhalt der `SKILL.md` (im Zip) unten an die Instruktionen an.

## Einen Trainer erstellen – vier Schritte

1. **Material geben.** Im Assistenten Ihr eigenes Arbeitsblatt, Ihren Hefteintrag oder Ihre Wortliste hochladen (PDF, Foto oder Text) – keine Buchseiten. Dazu schreiben Sie „Daraus bitte den Trainer.“
2. **Antwort lesen.** Der Assistent antwortet in drei Teilen:
   - einem kurzen **Plan**: welche Aufgaben ein Trainer werden, welche nicht und warum,
   - dem **Trainer-Code** (ein Kasten, beginnt mit `var NAME`),
   - einer **Kontrolltabelle** mit den Ergebnissen der Knopf-Aufgaben.

   Vergleichen Sie die Tabelle kurz mit Ihren Lösungen.
3. **Code in den Baukasten.** Den Kasten kopieren (Kopier-Symbol), den Baukasten öffnen (online oder `trainer-baukasten.html`), einfügen und auf „Trainer starten“ tippen.
4. **Prüfen und speichern.** Unten rechts muss „Selbsttest ✓ … Aufgaben geprüft“ stehen. Klicken Sie die Knopf-Aufgaben einmal durch. Danach oben auf „💾 Als Datei speichern“. Die gespeicherte Datei startet beim Öffnen sofort, auch offline und am iPad.

Erscheint statt des Selbsttests eine Meldung, kopieren Sie sie in den Assistenten. Er liefert dann einen korrigierten Code-Block. Änderungswünsche („nur Basis und Erweitert“, „bei c) noch die Probe“, „Satzglieder mit ‚Adverbialbestimmung‘ statt ‚Adverbiale‘“) gehen genauso.

## Welche Fächer und Themen passen?

Ein Trainer lohnt sich, wo es **ein Verfahren mit festen Schritten** oder **viele kurze Aufgaben mit eindeutiger Lösung** gibt:

| Fach | geeignet, zum Beispiel |
|---|---|
| Mathematik | Gleichungen, Terme, Text → Term, schriftliches Rechnen, Brüche, Primfaktoren, Einheiten |
| Latein (erprobt) | Formen bestimmen und bilden, Satzglieder bestimmen |
| andere Sprachen | Formen nach Regel bilden (Zeitformen, Steigerung), Formen bestimmen |
| Naturwissenschaften | Formeln umstellen, Einheiten umrechnen |

Nicht geeignet sind offene Aufgaben: Begründen, freies Schreiben, Übersetzen ganzer Texte, Interpretieren.

**Tipp für Sprachen:** Geben Sie eine kurze Wortliste aus Ihrem Unterricht mit (10 bis 20 Wörter) und nennen Sie die Begriffe, die Sie verwenden (z. B. „Adverbiale“ oder „Adverbialbestimmung“, Längenzeichen ja oder nein). Bitten Sie um einen Trainer pro Antwort – Sprach-Trainer brauchen mehr Daten als Mathe-Trainer.

## Bedienung im Unterricht

| Taste | Wirkung |
|---|---|
| → oder Leertaste | nächster Schritt (im Blitz: aufdecken / neue Aufgabe) |
| ← | einen Schritt zurück |
| A | alles zeigen |
| N | neue Zufallsaufgabe |
| 1–4 | Reiter wechseln |
| T | Tafelmodus (dunkel, kontrastreich) |
| F | Vollbild |
| + / − | Schrift größer / kleiner |

## Datenschutz

Der Trainer enthält nur Aufgaben und Lösungswege, keine Schülerdaten. Der Baukasten und die gespeicherten Dateien laufen vollständig im Browser und übertragen nichts. Im Fobizz-Assistenten arbeiten nur Sie als Lehrkraft. Laden Sie dort kein Material mit Namen oder Noten von Kindern hoch.

## Grenzen

Der Selbsttest prüft jede Knopf-Aufgabe und je Stufe 300 Zufallsaufgaben mit einer unabhängigen Kontrolle – in Mathematik mit Probe, in Sprachen mit von Hand geschriebenen Musterformen. Er prüft aber nur Ergebnisse, nicht die Didaktik. Ob die Schritte so erklärt sind, wie Sie es im Unterricht machen, sehen Sie beim einmaligen Durchklicken. Bricht eine Antwort ab, bitten Sie um höchstens zwei Trainer bzw. in Sprachen um einen. Hilft das nicht, schalten Sie „Erweitertes Denken“ aus.

## Lizenz

Texte und Anleitung: CC BY-SA 4.0 – Andreas Hemmeter. Code von Baukasten und Beispielen: MIT. Die Fobizz-Vorlage steht unter CC BY. Erstellt mit Unterstützung von Claude Cowork.
